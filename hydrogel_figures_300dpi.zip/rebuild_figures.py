from pathlib import Path
import os
import json
import shutil
import zipfile
import numpy as np
os.environ.setdefault('MPLCONFIGDIR', '/tmp/hydrogel-matplotlib-cache')
os.environ.setdefault('XDG_CACHE_HOME', '/tmp/hydrogel-font-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from PIL import Image
import xlsxwriter

ROOT = Path(__file__).resolve().parent
PANELS = ROOT / 'panels'
PANELS.mkdir(exist_ok=True)
BLUE, RED, ORANGE, GREEN, PINK = '#2454ff', '#ff324b', '#ff9800', '#13a34a', '#ef5aa3'
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 11, 'axes.linewidth': 1.1,
                     'axes.spines.top': False, 'axes.spines.right': False, 'savefig.facecolor': 'white'})
DATA = []

def series(name, x, y, color, error=None, linestyle='-', marker='o'):
    def values(items):
        return [v.item() if isinstance(v, np.generic) else v for v in items]
    return dict(name=name, x=values(x), y=values(y), color=color,
                error=None if error is None else values(error), linestyle=linestyle, marker=marker)

def record(key, title, xlabel, ylabel, items, kind='line', ylim=None, xlog=False, ylog=False,
           note='', spans=None):
    DATA.append(dict(key=key, title=title, xlabel=xlabel, ylabel=ylabel, series=items,
                     kind=kind, ylim=ylim, xlog=xlog, ylog=ylog, note=note, spans=spans or []))

# All numeric values below are manual reference-based approximations or explicit schematic values.
# No original experimental measurements, replicate counts, p-values, SD or SEM are available.
w = np.arange(4000, 649, -10)
spectra = []
for idx, (label, color, baseline) in enumerate([
        ('Diol-polymer', ORANGE, 4.8), ('PBA-polymer', BLUE, 3.6),
        ('H', RED, 2.4), ('H-I', GREEN, 1.2), ('Irisin', '#a126e8', 0.0)]):
    y = np.full_like(w, baseline, dtype=float)
    peaks = [(3310, 150, .52), (2920, 55, .13), (1715, 32, .4), (1600, 40, .48),
             (1510, 35, .33), (1410, 42, .24), (1300, 32, .44), (1200, 35, .40),
             (1110, 32, .31), (1030, 35, .45), (870, 27, .28)]
    for j, (center, width, amplitude) in enumerate(peaks):
        # Smooth synthetic peaks approximating the reference's visual appearance, not extracted spectra.
        a = amplitude * (1 + .18 * np.sin(idx + j))
        y -= a * np.exp(-.5 * ((w - center) / width) ** 2)
    spectra.append(series(label, w, np.round(y, 4), color, marker=''))
record('Figure1_C', 'FTIR spectra', 'Wavenumber (cm$^{-1}$)', 'Offset transmittance (a.u.)',
       spectra, kind='spectra', note='Synthetic spectrum shapes. Peak positions are illustrative; amplitude and baseline are arbitrary. No spectral assignments are validated.')

x = [10, 30, 50, 70, 90, 110, 130, 150]
record('Figure1_E', 'Pore size distribution', 'Pore size (µm)', 'Frequency (a.u.)', [
    series('H', x, [30, 120, 350, 340, 215, 90, 35, 7], BLUE, [10, 20, 60, 50, 40, 20, 10, 3]),
    series('H-I', x, [30, 150, 470, 430, 135, 60, 25, 4], RED, [10, 15, 25, 55, 20, 12, 8, 2])],
    kind='bar', ylim=(0, 600), note='The reference labels frequency as percent but its bars exceed 100. Use arbitrary units rather than interpreting these as normalized percentages. Error bars are schematic.')
x = [.1, .15, .23, .35, .5, .8, 1.2, 2, 3, 5, 8, 10]
record('Figure1_F', 'Rheological properties', 'Frequency (Hz)', 'Modulus (Pa)', [
    series("H G′", x, [70, 85, 85, 92, 102, 110, 115, 120, 128, 135, 145, 155], BLUE),
    series("H G″", x, [9, 9, 10, 11, 12, 13, 14, 16, 18, 19, 21, 23], BLUE, linestyle='--'),
    series("H-I G′", x, [110, 135, 145, 155, 160, 175, 185, 198, 210, 220, 240, 245], RED),
    series("H-I G″", x, [6, 6.3, 6.5, 7.5, 8, 9, 10, 10.5, 11.2, 12, 13, 14], RED, linestyle='--')],
    xlog=True, ylog=True, ylim=(.1, 10000), note='Manually estimated trend values from the reference. No significance testing is possible.')
x = np.arange(0, 501, 10)
h = np.where(((x >= 120) & (x < 205)) | ((x >= 300) & (x < 385)),
             23 + 3*np.sin(x/16), 1120 + 90*np.sin(x/66))
hi = np.where(((x >= 120) & (x < 205)) | ((x >= 300) & (x < 385)),
              28 + 3*np.cos(x/15), 900 + 60*np.sin(x/55))
record('Figure1_G', 'Self-healing / shear recovery', 'Time (s)', 'G′ (Pa)', [
    series('H', x, np.round(h, 2), BLUE), series('H-I', x, np.round(hi, 2), RED)],
    ylog=True, ylim=(1, 10000), spans=[(120, 205, 'High strain'), (300, 385, 'High strain')],
    note='Synthetic step-recovery traces approximating the reference. Transition times and within-state variation are illustrative; strain values are unknown.')
x = ['Glass', 'Skin (wet)', 'Metal', 'Plastic']
record('Figure1_J', 'Adhesive strength', 'Substrate', 'Lap shear strength (kPa)', [
    series('H', x, [52, 44, 34, 28], BLUE, [8, 6, 6, 5]),
    series('H-I', x, [55, 47, 37, 30], RED, [9, 6, 5, 5])], kind='bar', ylim=(0, 80),
    note='Estimated bar heights; error bars are schematic. No original replicates or statistics available.')
x = [0, 3, 7, 10, 14, 17, 21, 24, 28]
record('Figure1_K', 'Degradation / stability', 'Time (days)', 'Remaining mass (%)', [
    series('H', x, [100, 94, 87, 80, 74, 67, 62, 56, 49], BLUE, [0, 5, 6, 6, 7, 6, 7, 6, 7]),
    series('H-I', x, [100, 98, 94, 87, 82, 76, 73, 67, 61], RED, [0, 5, 6, 6, 7, 6, 7, 6, 7])],
    ylim=(0, 120), note='Approximate reference-based values. Error bars are schematic.')

x = [0, 5, 10, 15, 20]
record('Figure2_B', 'Glucose-dependent swelling', 'Glucose concentration (mM)', 'Swelling ratio (%)', [
    series('H', x, [145, 220, 280, 340, 405], BLUE, [20, 25, 30, 35, 30]),
    series('H-I', x, [170, 250, 300, 370, 445], RED, [20, 25, 30, 35, 30])], kind='bar', ylim=(0, 600),
    note='Approximate reference-based values. Error bars are schematic; no p-values can be recomputed.')
x = list(range(0, 25, 2))
record('Figure2_C', 'Dynamic glucose response', 'Time (h)', 'Swelling ratio (%)', [
    series('H', x, [0, 180, 260, 330, 410, 390, 230, 200, 235, 330, 390, 420, 430], BLUE,
           [0, 25, 25, 30, 30, 35, 30, 25, 25, 30, 30, 30, 30]),
    series('H-I', x, [0, 205, 280, 370, 440, 420, 245, 210, 255, 370, 430, 450, 460], RED,
           [0, 25, 25, 30, 30, 35, 30, 25, 25, 30, 30, 30, 30])], ylim=(0, 600),
    spans=[(0, 6, '5.5 mM'), (6, 12, '10 mM'), (12, 18, '5.5 mM'), (18, 24, '10 mM')],
    note='Values and concentration-change times visually approximated from the reference; error bars are schematic.')
x = ['5.5', '6.5', '7.4', '8.0']
record('Figure2_E', 'pH-dependent swelling', 'pH', 'Swelling ratio (%)', [
    series('H', x, [270, 270, 200, 195], BLUE, [25, 30, 25, 20]),
    series('H-I', x, [295, 295, 235, 215], RED, [25, 30, 25, 20])], kind='bar', ylim=(0, 600),
    note='Approximate reference-based bar heights; error bars are schematic.')
x = [0, 3, 7, 14, 21, 24, 28]
record('Figure2_F', 'pH-dependent degradation', 'Time (days)', 'Remaining mass (%)', [
    series('pH 5.5', x, [100, 74, 47, 35, 26, 20, 15], RED, [0, 5, 7, 6, 6, 6, 6]),
    series('pH 6.5', x, [100, 80, 64, 51, 45, 36, 33], ORANGE, [0, 5, 7, 6, 6, 6, 6]),
    series('pH 7.4', x, [100, 88, 80, 72, 65, 60, 56], BLUE, [0, 5, 7, 6, 6, 6, 6]),
    series('pH 8.0', x, [100, 84, 71, 63, 55, 49, 45], GREEN, [0, 5, 7, 6, 6, 6, 6])],
    ylim=(0, 120), note='Approximate reference-based values. Error bars are schematic.')
x = ['0.1', '0.5', '1.0', '2.0']
record('Figure2_G', 'Drug loading efficiency', 'Initial irisin (mg/mL)', 'Percentage (%)', [
    series('EE', x, [47, 49, 53, 61], BLUE, [6, 6, 7, 8]),
    series('LC', x, [50, 55, 60, 67], RED, [6, 6, 7, 8])], kind='bar', ylim=(0, 100),
    note='Approximate heights matching the reference. EE/LC definitions and experimental denominators are unknown. Error bars are schematic.')
x = [0, 6, 12, 24, 36, 48, 72]
record('Figure2_H', 'Glucose-dependent irisin release', 'Time (h)', 'Cumulative release (%)', [
    series('5.5 mM', x, [0, 7, 11, 16, 20, 24, 30], BLUE, [0, 2, 3, 4, 4, 5, 5]),
    series('10 mM', x, [0, 13, 22, 32, 39, 46, 55], ORANGE, [0, 3, 4, 5, 5, 6, 6]),
    series('15 mM', x, [0, 9, 16, 25, 32, 37, 43], GREEN, [0, 2, 3, 4, 4, 5, 5]),
    series('20 mM', x, [0, 18, 33, 45, 54, 64, 74], RED, [0, 3, 4, 5, 6, 7, 7])],
    ylim=(0, 100), note='Approximate reference-based trend values. The visually shown 10/15 mM ordering is retained; it is not a validated concentration-response relationship.')
record('Figure2_I', 'pH-dependent irisin release', 'Time (h)', 'Cumulative release (%)', [
    series('pH 5.5', x, [0, 15, 30, 48, 60, 69, 82], RED, [0, 3, 4, 5, 6, 7, 7]),
    series('pH 6.5', x, [0, 9, 17, 27, 34, 43, 54], ORANGE, [0, 3, 4, 5, 5, 6, 6]),
    series('pH 7.4', x, [0, 5, 10, 16, 20, 26, 35], BLUE, [0, 2, 3, 4, 4, 5, 5]),
    series('pH 8.0', x, [0, 4, 7, 11, 14, 18, 22], GREEN, [0, 2, 3, 4, 4, 5, 5])],
    ylim=(0, 100), note='Approximate reference-based values. Error bars are schematic.')
x = ['pH 6.5', 'pH 7.4']
record('Figure2_J', 'Combined pH and glucose release', 'pH', 'Cumulative release (%)', [
    series('5.5 mM', x, [22, 20], BLUE, [3, 3]),
    series('10 mM', x, [40, 39], ORANGE, [4, 5]),
    series('20 mM', x, [63, 55], PINK, [4, 4])], kind='bar', ylim=(0, 100),
    note='Approximate reference bar heights. Measurement endpoint is unknown. Error bars are schematic; reference significance stars are not reproduced.')
x = list(range(0, 49, 4))
record('Figure2_K', 'On/off release under glucose fluctuation', 'Time (h)', 'Cumulative release (%)', [
    series('H-I (glucose-responsive)', x, [0, 27, 43, 54, 60, 65, 58, 63, 66, 76, 81, 87, 91], RED),
    series('NRH-I (non-responsive)', x, [0, 12, 23, 31, 35, 37, 39, 41, 44, 46, 48, 51, 54], '#666666', marker='s')],
    ylim=(0, 100), spans=[(0, 8, '10 mM'), (8, 18, '5.5 mM'), (18, 30, '10 mM'),
                        (30, 40, '5.5 mM'), (40, 48, '10 mM')],
    note='Trace shape only, manually approximated. The reference-like dip in cumulative release should not be interpreted as validated physical behavior or used to infer release kinetics. No original time series is available.')
x = ['Control', 'Blank hydrogel', 'Released irisin\n(low pH)', 'Free irisin']
record('Figure2_L', 'Bioactivity of released irisin', 'Group', 'Relative p-AKT signal (a.u.)', [
    series('Illustrative relative signal', x, [.45, .75, 1.20, 1.25], BLUE, [.05, .08, .12, .10])],
    kind='blotbar', ylim=(0, 1.6), note='Schematic relative signal heights, not densitometry. Not calculated from real bands. Blot is generated; significance and biological activity are not established.')

def decorate(ax, d):
    ax.set_xlabel(d['xlabel'])
    ax.set_ylabel(d['ylabel'])
    if d['ylim']: ax.set_ylim(*d['ylim'])
    if d['xlog']: ax.set_xscale('log')
    if d['ylog']: ax.set_yscale('log')
    if d['spans']:
        for i, (lo, hi, text) in enumerate(d['spans']):
            ax.axvspan(lo, hi, color=RED if 'strain' in text or i % 2 else BLUE, alpha=.065)
            ax.text((lo+hi)/2, .95, text, transform=ax.get_xaxis_transform(), ha='center', va='top', fontsize=9)
    ax.tick_params(direction='out', length=4)

def draw_chart(ax, d):
    if d['kind'] in ('bar', 'blotbar'):
        labels = d['series'][0]['x']
        positions = np.arange(len(labels))
        n = len(d['series'])
        width = .72/n
        for idx, s in enumerate(d['series']):
            loc = positions + (idx-(n-1)/2)*width
            if d['kind']=='blotbar':
                colors = [BLUE, ORANGE, RED, '#888888']
                ax.bar(loc, s['y'], width=width, color=colors, alpha=.60, edgecolor=colors,
                       yerr=s['error'], capsize=4, error_kw={'linewidth':1})
            else:
                ax.bar(loc, s['y'], width=width, color=s['color'], alpha=.28, edgecolor=s['color'],
                       linewidth=1.2, label=s['name'], yerr=s['error'], capsize=3,
                       error_kw={'ecolor':s['color'], 'linewidth':1})
        ax.set_xticks(positions, [str(v) for v in labels])
        if d['key']=='Figure1_E': ax.tick_params(axis='x', labelsize=9)
        if d['kind']=='blotbar': ax.tick_params(axis='x', labelsize=9)
    else:
        for s in d['series']:
            ax.errorbar(s['x'], s['y'], yerr=s['error'], color=s['color'], label=s['name'],
                        linewidth=1.6, linestyle=s['linestyle'], marker=s['marker'], markersize=4.0,
                        markerfacecolor='white', markeredgewidth=1, capsize=3, elinewidth=.9)
        if d['kind']=='spectra':
            ax.set_xlim(4000, 650)
            ax.set_yticks([])
            for s in d['series']:
                ax.text(690, s['y'][-1]+.12, s['name'], ha='right', va='center', fontsize=9, color=s['color'])
        else:
            all_x = [v for s in d['series'] for v in s['x']]
            ax.set_xlim(min(all_x), max(all_x))
            if not d['xlog']: ax.xaxis.set_major_locator(MaxNLocator(7))
    decorate(ax, d)
    if d['kind'] not in ('spectra','blotbar'):
        ax.legend(frameon=False, fontsize=9, loc='lower right' if d['spans'] else 'upper right',
                  ncol=2 if len(d['series'])>2 else 1)

def save_plot(d):
    blot_file = ROOT/'generated_assets'/'Figure2_L_blot.png'
    if d['kind']=='blotbar' and blot_file.exists():
        fig=plt.figure(figsize=(7.2,7.0))
        ax_img=fig.add_axes([.06,.46,.89,.40])
        with Image.open(blot_file) as im: ax_img.imshow(im)
        ax_img.axis('off')
        ax=fig.add_axes([.14,.16,.77,.27])
    else:
        fig=plt.figure(figsize=(7.2,5.1))
        ax=fig.add_axes([.14,.17,.79,.66])
    letter=d['key'].split('_')[1]
    title=d['title']
    fig.text(.035,.945,letter,fontsize=22,weight='bold',va='top')
    fig.text(.095,.938,title,fontsize=14 if len(title)>37 else 16,weight='bold',va='top')
    draw_chart(ax,d)
    fig.text(.5,.027,'REFERENCE-BASED ESTIMATE / SCHEMATIC — NOT ORIGINAL DATA',
             ha='center',fontsize=8,color='#8a3131')
    fig.savefig(PANELS/(d['key']+'.tiff'),dpi=300,format='tiff',
                pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)

def workbook():
    target=ROOT/'参考图重绘_绘图数据.xlsx'
    wb=xlsxwriter.Workbook(target)
    heading=wb.add_format({'bold':True,'font_size':14,'font_color':'#9c2424','text_wrap':True})
    note_fmt=wb.add_format({'text_wrap':True,'font_color':'#7e2424','valign':'top','bg_color':'#fff4ed'})
    header=wb.add_format({'bold':True,'bg_color':'#dce8fa','border':1,'text_wrap':True})
    number=wb.add_format({'num_format':'0.0000'})
    info=wb.add_worksheet('说明_README')
    info.set_column('A:A',27);info.set_column('B:B',95)
    info.merge_range('A1:B2','参考图估读与示意重建 / Reference-based estimates and illustrative reconstructions',heading)
    notices=[
      ('数据来源','用户提供的组合截图；没有原始实验数据。数值由视觉估读或为匹配图形趋势而构造，并非像素级数字化结果。'),
      ('用途限制','仅适用于版式、教学及示意展示。不可作为真实实验测量、科研结论、统计检验或真实 SEM/Western blot 证据。'),
      ('误差列','Y_error_schematic 列为示意误差棒长度，不是计算得到的 SD、SEM 或置信区间；没有重复数 n。'),
      ('统计标记','未重绘 ns 或显著性星号；没有原始数据，无法支持或重新计算 p 值。'),
      ('谱图','Figure 1C 为合成示意谱形；峰位参考截图大致形态，强度及偏移任意；不可用于物质鉴定。'),
      ('孔径直方图','参考图频率轴标注 % 但柱高超过 100；此处以任意单位 a.u. 表示，不当作概率或百分比。'),
      ('照片及成像','Figure 1B/D/H/I 和 Figure 2L 的 blot 是生成的示意重建，均在图中标注；SEM 不提供虚构的校准标尺。'),
      ('Figure 2K','曲线仅参考视觉形状；累计释放曲线局部下降不代表验证过的物理行为，不能据此拟合释放动力学。'),
      ('Excel 图表','16 个数值页均含原生可编辑 Excel 图表，改动表格数据后图表随之更新。Excel 图表为数据编辑预览，完整版式见 TIFF。'),
      ('工作簿结构','每个数值页按系列重复三列 X、Y_reference_estimate、Y_error_schematic；没有可用误差时误差列留空。'),
      ('TIFF 规格','300 dpi，LZW 无损压缩。新绘制统计图为 2160×1530 像素（Figure 2L 为 2160×2100）；原有机制图保留原始像素尺寸。'),
      ('重现脚本','rebuild_figures.py 与 generated_assets 保存在同一目录；用 Python、numpy、matplotlib、Pillow、xlsxwriter 可重建 Excel 与 TIFF。'),
    ]
    for row,(label,content) in enumerate(notices,3):
        info.write(row,0,label,header);info.write(row,1,content,note_fmt);info.set_row(row,48)
    index=wb.add_worksheet('23分面索引')
    index.set_column('A:A',17);index.set_column('B:B',48);index.set_column('C:C',65)
    index.write_row(0,0,['Panel','Title','Source / status'],header)
    all_titles={d['key']:d['title'] for d in DATA}
    all_titles.update({'Figure1_A':'Schematic illustration of hydrogel fabrication',
      'Figure1_B':'Photographs','Figure1_D':'SEM images','Figure1_H':'Macroscopic self-healing',
      'Figure1_I':'Adhesion to various substrates','Figure2_A':'Glucose-responsive mechanism',
      'Figure2_D':'pH-responsive mechanism'})
    row=1
    for fig,last in [(1,'K'),(2,'L')]:
        for c in range(ord('A'),ord(last)+1):
            key=f'Figure{fig}_{chr(c)}'
            source='REFERENCE ESTIMATE / SCHEMATIC VALUES' if key in {d['key'] for d in DATA} else 'ILLUSTRATIVE IMAGE / CONCEPTUAL SCHEMATIC; NO NUMERIC DATA'
            index.write_row(row,0,[key,all_titles[key],source]);row+=1
    for d in DATA:
        ws=wb.add_worksheet(d['key']);n=len(d['series']);cols=max(8,n*3)
        ws.set_column(0,cols-1,20)
        ws.merge_range(0,0,0,cols-1,d['key']+' — '+d['title'],heading)
        ws.merge_range(1,0,1,cols-1,'REFERENCE ESTIMATE / SCHEMATIC ONLY — NOT ORIGINAL EXPERIMENTAL DATA. Error bars are schematic, not SD/SEM. '+d['note'],note_fmt)
        ws.set_row(1,65);ws.freeze_panes(4,0)
        ws.write(2,0,'X: '+d['xlabel']);ws.write(2,3,'Y: '+d['ylabel'])
        chart=wb.add_chart({'type':'column' if d['kind'] in ('bar','blotbar') else 'scatter',
                            **({} if d['kind'] in ('bar','blotbar') else {'subtype':'straight_with_markers'})})
        for i,s in enumerate(d['series']):
            col=i*3
            ws.write_row(3,col,[s['name']+' | X',s['name']+' | Y_reference_estimate',s['name']+' | Y_error_schematic'],header)
            ws.set_row(3,45)
            for j,(x,y) in enumerate(zip(s['x'],s['y']),4):
                if isinstance(x,(str,np.str_)):ws.write_string(j,col,str(x).replace('\n',' '))
                else:ws.write_number(j,col,float(x),number)
                ws.write_number(j,col+1,float(y),number)
                if s['error'] is not None:ws.write_number(j,col+2,float(s['error'][j-4]),number)
            last=3+len(s['x'])
            spec={'name':s['name'],'categories':[d['key'],4,col,last,col],
                  'values':[d['key'],4,col+1,last,col+1], 'line':{'color':s['color'],'width':1.5},
                  'fill':{'color':s['color'],'transparency':55}}
            if d['kind'] not in ('bar','blotbar'):
                spec['marker']={'type':'none' if d['kind']=='spectra' else ('square' if s['marker']=='s' else 'circle'),
                                'size':4,'border':{'color':s['color']},'fill':{'color':'white'}}
                if s['linestyle']=='--':spec['line']['dash_type']='dash'
            if s['error'] is not None:
                spec['y_error_bars']={'type':'custom','plus_values':[d['key'],4,col+2,last,col+2],
                                     'minus_values':[d['key'],4,col+2,last,col+2], 'line':{'color':s['color']}}
            if d['kind']=='blotbar':
                spec['points']=[{'fill':{'color':c,'transparency':40},'border':{'color':c}} for c in [BLUE,ORANGE,RED,'#888888']]
            chart.add_series(spec)
        xlabel=d['xlabel'].replace('$^{-1}$','⁻¹')
        xa={'name':xlabel};ya={'name':d['ylabel']}
        if d['xlog']:xa['log_base']=10
        if d['ylog']:ya['log_base']=10
        if d['ylim']:ya.update(min=d['ylim'][0],max=d['ylim'][1])
        if d['kind']=='spectra':xa.update(reverse=True,min=650,max=4000)
        chart.set_x_axis(xa);chart.set_y_axis(ya)
        chart.set_title({'name':d['title']+' [reference estimate / schematic]'})
        chart.set_legend({'position':'bottom'});chart.set_size({'width':780,'height':450})
        ws.insert_chart(3,cols+1,chart)
    wb.close()
    return target

def finalize():
    for d in DATA:save_plot(d)
    target=workbook()
    (ROOT/'绘图数据_来源说明.json').write_text(json.dumps(DATA,ensure_ascii=False,indent=2),encoding='utf-8')
    spec=[]
    for p in sorted(PANELS.glob('*.tiff')):
        # Convert RGBA plot output to RGB losslessly, preserving pixels and setting explicit TIFF tags.
        with Image.open(p) as im:
            rgb=im.convert('RGB')
            rgb.save(p,format='TIFF',compression='tiff_lzw',dpi=(300,300))
        with Image.open(p) as im:
            assert im.mode=='RGB' and im.tag_v2[259]==5 and tuple(im.info['dpi'])==(300,300)
            spec.append({'file':p.name,'size':list(im.size),'dpi':300,'compression':'LZW','mode':'RGB'})
    (ROOT/'TIFF_规格.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'workbook':str(target),'numeric_sheets':len(DATA),'tiff_count':len(spec)},ensure_ascii=False))

if __name__=='__main__':finalize()
